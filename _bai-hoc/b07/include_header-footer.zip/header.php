
<a href="<?php echo $_SERVER['PHP_SELF'] ?>">
<img src="https://s1.vnecdn.net/vnexpress/restruct/i/v799/v2_2019/pc/graphics/logo.svg">
</a>
<br>
<br>
<a href="<?php echo $_SERVER['PHP_SELF'] ?>">HOME</a>
|
<a href="<?php echo $_SERVER['PHP_SELF'] ?>?page=news">Tin tức</a>
|
<a href="<?php echo $_SERVER['PHP_SELF'] ?>?page=product">Sản phẩm</a>