<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

<style>
    table {
        width: 100%;
    }
    td input, td textarea{
        width: 100%
    }
</style>

<b style="color: red">ADMIN</b>
<hr>
<a href="/">Trang Chủ</a> |
<a href="/admin/news">Tin tức</a> |
<a href="/admin/products">Sản phẩm</a> |
<a href="/admin/orders">Đơn hàng</a> |
<a href="/admin/users">Người dùng</a>
<hr>

