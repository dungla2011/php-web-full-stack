<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body style='' >

<b>HOME</b>
<hr>
<a href="/">Trang Chủ</a> |
<a href="/news">Tin tức</a> |
<a href="/products">Sản phẩm</a> |
<a href="/member">Thành viên</a> |
<a href="/admin">ACP</a>
<hr>

