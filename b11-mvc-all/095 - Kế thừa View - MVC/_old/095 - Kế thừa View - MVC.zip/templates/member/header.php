<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

<b style="color: green">
MEMBER</b>
<hr>
<a href="/">Trang Chủ</a> |
<a href="/member/orders">Đơn hàng</a> |
<a href="/member">Tài khoản</a>
<hr>

