<?php

class AdminController {
    public function index() {
        // Gọi view để hiển thị trang chu
        require '../app/views/adminIndex.php';
    }
}
