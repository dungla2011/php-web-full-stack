<?php

class MemberController {
    public function index() {
        // Gọi view để hiển thị trang chu
        require '../app/views/memberIndex.php';
        //echo "MEMBER content...";
    }
}
