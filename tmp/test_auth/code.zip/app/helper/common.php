<?php


function echored($str){
    echo "<span style='color: red'> $str </span>";
}