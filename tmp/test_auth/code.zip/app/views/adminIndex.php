<?php 
require_once "../templates/admin/header.php"
?>

<p></p>
Nội dung trang Admin Index

<?php 
require_once "../templates/admin/footer.php"
?>