<?php 
require_once "../templates/member/header.php"
?>

<p></p>
Nội dung trang Member Index

<?php 
require_once "../templates/member/footer.php"
?>