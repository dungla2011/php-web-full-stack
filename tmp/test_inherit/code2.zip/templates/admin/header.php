<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

<b style="color: red">ADMIN</b>

<?php
require '../templates/logined.php';
?>


<hr>
<a href="/">Trang Chủ</a> |
<a href="/admin/news">Tin tức</a> |
<a href="/admin/products">Sản phẩm</a> |
<a href="/admin/orders">Đơn hàng</a> |
<a href="/admin/users">Người dùng</a>
<hr>

