<?php

class HomeController {
    public function index() {
        // Gọi view để hiển thị trang chu
        require '../app/views/homeIndex.php';
    }
}
