<?php 
require_once "../templates/home/header.php"
?>

Đây là trang chủ HOME


<?php 
require_once "../templates/home/footer.php"
?>